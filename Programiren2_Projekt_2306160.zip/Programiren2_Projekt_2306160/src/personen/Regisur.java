package personen;

public class Regisur extends Person {
    public Regisur(String name, int id) {
        super(name, id );
    }
}
